<?php  
// -----------------------------------------------------
// index.php
// -----------------------------------------------------

// Incluimos la conexion
require "php/conexion.php";

// Incluimos el archivo de funciones
require "php/funciones.php";

// -------------------
// Codigo Principal
// -------------------

// Obtenemos el Nombre del Host
$computadora =  gethostname();

// Preparando el Query para verificar si hay una sesion para este hostName
$query = "SELECT id FROM sesiones WHERE  computadora = '$computadora'";
echo $query;
        
// Ejecuta Query y obtiene Registros
$registros = $conexion->query($query);

// Vaerifica que hay registros
if ($registros)
{   
    // Inicializa hostName
    $sesion = "";

    // Ciclo para procesar cada registro de usario
    while ($fila = $registros->fetch_assoc()) 
    { 
        // Obtiene la Sesión
        $sesion = $fila['id'];            
    }

    // Verifica si la sesion es valida
    if (fnSesionValida($conexion,$sesion))
        // Lanza principal
        header("Location: principal.html?sesion=".$sesion);
    else
        // Lanza el Index
        header("Location: login.html");
}
else
{
    // Lanza el Index
    header("Location: login.html");
}

?>