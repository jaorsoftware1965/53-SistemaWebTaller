<?php  
// -----------------------------------------------------
// validarSesion.php
// -----------------------------------------------------

// Incluimos la conexion y funciones
require "conexion.php";
require "funciones.php";


// Verificamos que hayan llegado los datos
if (isset($_GET['sesion']))
{
    // Obtenemos los 2 datos
    $sesion = $_GET['sesion'];

    // Vaerifica que hay registros
    if (fnSesionValida($conexion,$sesion))
       echo "ok";
    else
       echo "false";	
}
else
{
   // Retorna false
   echo "false";
}

?>