<?php  
// -----------------------------------------------------
// insertarVariable.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Incluimos el archivo de funciones
require "funciones.php";

// -------------------
// Codigo Principal
// -------------------

// Verificamos que hayan llegado los datos
if (isset($_POST['numSesion']) &&
	isset($_POST['varNombre']) && 
    isset($_POST['varValor']))
{
	// Obtiene los datos
	$sesion = $_POST['numSesion'];
	$nombre = $_POST['varNombre'];
	$valor  = $_POST['varValor'];	

	// Verifica que la sesión sea valida primero
	if (fnSesionValida($conexion,$sesion))
	{
		// Prepara el Query para la Inserción
		$query  = " INSERT INTO sesionesVariables ";
		$query .= " (sesion, nombre, valor)";
		$query .= " VALUES ";
		$query .= " ('$sesion','$nombre','$valor')";

		// Ejecuta Query y obtiene Registros
		$registros = $conexion->query($query);

		// Verifica
		if ($registros)
		{   
			// Lanza de Nuevo la forma principal
			header("Location: ../principal.html?sesion=$sesion");
		}   
		else
		{   
			// Activa la venta de error
		    header("Location: ../error.html?mensaje=".mysqli_error($conexion)."&paginaRegresar=principal.html?sesion=".$sesion);   
		}
	}
	else
	{
		// Activa la venta de error
		header("Location: ../error.html?paginaRegresar=login.html&mensaje=La Sesion ya no es valida");   
	}
}
else
{
	// Faltaron datos en 
	header("Location: ../error.html?paginaRegresar=login.html&mensaje=Violacion de Acceso");   
}
?>