<?php  
// -----------------------------------------------------
// eliminarVariable.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Incluimos las Funciones
require "funciones.php";

// Verificamos que hayan llegado los datos
if (isset($_POST['numSesion']) &&
    isset($_POST['varNombre']))
{
    // Obtiene los datos
 	 $sesion = $_POST['numSesion'];
 	 $nombre = $_POST['varNombre'];

    // Verifica que la sesión sea valida primero
	 if (fnSesionValida($conexion,$sesion))
	 { 
       // Preparando el Query para eliminar la sesión
       $query  = " DELETE FROM sesionesVariables";
       $query .= " WHERE  sesion = ".$sesion;
       $query .= " AND    nombre = '".$nombre."'";
       echo $query;

       // Ejecuta Query y obtiene Registros
	    $registros = $conexion->query($query);

       // Vaerifica que hay registros
	    if ($registros)
	    {    
          // Verifica si afecto
          if (mysqli_affected_rows($conexion)>0)        
          {
             // Lanza de Nuevo la forma principal
             header("Location: ../principal.html?sesion=$sesion");
          }             
          else        
          {
             // Activa la venta de error
             header("Location: ../error.html?mensaje=No se encontro la variable&paginaRegresar=principal.html?sesion=".$sesion);   
          }             
	    }  
       else
       {
          // Activa la venta de error
          header("Location: ../error.html?mensaje=".$conexion->error."&paginaRegresar=principal.html?sesion=".$sesion);   
       }          
    }
}
else
{
   // Activa la venta de error
   header("Location: ../error.html?mensaje=Violacion de Acceso&paginaRegresar=login.html");   
}

?>