<?php  
// -----------------------------------------------------
// salir.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['numeroSesion']))
{
   // Obtenemos el dato
   $numeroSesion = $_GET['numeroSesion'];    

   // Preparando el Query para la Consulta
   $query  = " DELETE FROM sesiones";
   $query .= " WHERE id = ".$numeroSesion;    
   echo $query;

   // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

   // Vaerifica que hay registros
	if ($registros)
	{    
        // Activa la Venta de Login
        header("Location: ../login.html");        
	}  
   else
   {
       // Error
       die ("Error en Consulta :<br>".mysqli_errno($conexion));
   }

   // Imprime el Resultado
   echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta salir";
}

?>