<?php  
// -----------------------------------------------------
// cargarSesiones.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Incluimos el archivo de funciones
require "funciones.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['numSesion']))
{
    // Obtiene el dato de la sesion
	$sesion = $_GET['numSesion'];

    // Verifica que la sesión sea valida primero
	if (fnSesionValida($conexion,$sesion))
	{
        // Preparando el Query para la Consulta
        $query = "SELECT * FROM sesiones ORDER BY fechaHora";
        

        // Ejecuta Query y obtiene Registros
        $registros = $conexion->query($query);

        // Vaerifica que hay registros
        if ($registros)
        {   
            // Crea los encabezados de la tabla
            echo "<tr>\n";
            echo "  <th>Sesion</th>\n";
            echo "  <th>Fecha Hora</th>\n";
            echo "  <th>Duracion</th>\n";
            echo "  <th>Fecha Hora Final</th>\n";
            echo "  <th>Host Name</th>\n";
            echo "</tr>\n";

            // Ciclo para procesar cada registro de usario
            while ($fila = $registros->fetch_assoc()) 
            { 
                // Crea el Renglon html 
                echo "<tr>\n";
                
                // Coloca los datos para cada columna
                echo "   <td>".$fila['id']."</td>\n";
                echo "   <td>".$fila['fechaHora']."</td>\n";
                echo "   <td>".$fila['duracion']."</td>\n";
                echo "   <td>".$fila['fechaHoraFin']."</td>\n";
                echo "   <td>".$fila['hostName']."</td>\n";

                // Cierra el Renglon html 
                echo "</tr>\n";
            }
        }
    }  
    else
    {
        echo "La Sesion ya no es valida";
    }      
}
else
{
    // Mensaje de Error
    echo "Intento de Acceso NO valido ...";
}
?>